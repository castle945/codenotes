from setuptools import setup, find_packages

setup(
    name="pt4c",
    version="0.0.0",
    packages=find_packages(),
    author="city945",
    author_email="city945@njust.edu.cn",
    url="https://github.com/city945",
    description="A python utils package for city945",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
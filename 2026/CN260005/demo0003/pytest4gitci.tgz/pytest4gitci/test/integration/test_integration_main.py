import unittest
from pt4c.main import *

class TestMain(unittest.TestCase):
    def test_main(self):
        self.assertTrue(subtract(5, 2) == 3)

if __name__ == '__main__':
    unittest.main()